(* Streams are a value/thunk pair *)

(* Data definition *)
type 'a stream = Pair of 'a * (unit -> 'a stream)

let head : 'a stream -> 'a
  = function (Pair(hd,_)) -> hd

let tail : 'a stream -> 'a stream
  = function (Pair(_,tl)) -> tl ()


(* Utils *)
let ( ** ) : ('b -> 'c) -> ('a -> 'b) -> 'a -> 'c
  = fun f g -> fun x -> f (g x)

let swap (a,b) = (b,a)

let (><) : ('a -> 'b) -> ('c -> 'd) -> ('a * 'c) -> ('b * 'd)
  = fun f g (a,b) -> (f a, g b)

let rec take : int -> 'a stream -> 'a list
  = fun n st ->
  if n < 1
  then []
  else (head st) :: take (pred n) (tail st)

let id x = x

let list_of_string str =
  let xs = ref [] in
  let () = String.iter (fun c -> xs := (Char.escaped c) :: !xs) str in
  List.rev !xs

let string_of_list f xs =
  Format.sprintf "[%s]" (String.concat "; " (List.map f xs))

let string_of_pair (a,b) =
  Format.sprintf "(%d, %d)" a b

let print_stream ?(n=5) ~name ~f str =
  Format.printf "%s := [%s ...\n" name @@
    String.concat "; " @@
      List.map f @@ take n str

(******************************************************************************)

let rec univ : ('a -> 'b) -> ('a -> 'a) -> 'a -> 'b stream
  = fun obs nxt seed -> Pair (obs seed, fun () -> univ obs nxt (nxt seed))

let nats : int stream
  = univ id succ 0

let evens : 'a stream -> 'a stream
  = fun st -> univ head (tail ** tail) st

let odds : 'a stream -> 'a stream
  = fun st -> evens @@ tail st

let repeat : 'a -> 'a stream
  = fun x -> univ id id x

let map : ('a -> 'b) -> 'a stream -> 'b stream
  = fun f -> univ (f ** head) tail

let interleave : 'a stream -> 'a stream -> 'a stream
  = fun xs ys -> univ (head ** fst) (swap ** (tail >< id)) (xs, ys)

let zip : 'a stream -> 'b stream -> ('a * 'b) stream
  = fun xs ys -> univ (head >< head) (tail >< tail) (xs, ys)

let suffixes : 'a stream -> 'a stream stream
  = fun st -> univ id tail st

let prod : 'a stream -> 'b stream -> ('a * 'b) stream stream
  = fun s1 s2 ->
  let y_axis = (fun (xs,ys) -> zip (repeat (head xs)) ys) in
  univ y_axis (tail >< id) (s1, s2)

let diag : ('a stream) stream -> 'a stream
  = fun st ->
  univ (head ** head) (tail ** (map tail)) st

let fib : int stream
  = let next = fun (p1, p2) -> (p2, p1 + p2) in
    univ snd next (0, 1)

let look_and_say : int -> int stream
  =
  let say xs =
    match xs with
    | [] -> []
    | m::_ -> m :: string_of_int (List.length xs) :: []
  in
  let look (prev, acc) n =
    match prev with
    | m::_ when n=m -> (n::prev, acc)
    | _ -> ([n], say prev @ acc)
  in
  let next n =
    int_of_string @@
      String.concat "" @@
        List.rev @@
          (fun (leftovers,acc) -> say leftovers @ acc) @@
            List.fold_left look ([],[]) (list_of_string (string_of_int n))
  in
  univ id next

(******************************************************************************)

let () =
  let () = print_stream ~name:"nats"
                        ~f:string_of_int
                        nats in
  let () = print_stream ~name:"even nats"
                        ~f:string_of_int
                        (evens nats) in
  let () = print_stream ~name:"odd nats"
                        ~f:string_of_int
                        (odds nats) in
  let () = print_stream ~name:"snorlax"
                        ~f:id
                        (repeat "zzz") in
  let () = print_stream ~name:"map 10 nats"
                        ~f:string_of_int
                        (map ((+)10) nats) in
  let () = print_stream ~name:"interleave odds evens"
                        ~f:string_of_int
                        (interleave (odds nats) (evens nats)) in
  let () = print_stream ~name:"404"
                        ~f:string_of_int
                        (interleave (repeat 4) (repeat 0)) in
  let () = print_stream ~name:"zip 0 nats"
                        ~f:string_of_pair
                        (zip (repeat 0) nats) in
  let () = print_stream ~name:"suffixes/5 nats"
                        ~f:(fun x -> string_of_list string_of_int @@ take 5 x)
                        (suffixes nats) in
  let () = print_stream ~name:"diag (prod nats)"
                        ~f:string_of_pair
                        (diag @@ prod nats nats) in
  let () = print_stream ~name:"fib"
                        ~f:string_of_int
                        fib in
  let () = print_stream ~name:"look & say"
                        ~f:string_of_int
                        (look_and_say 1) in
  ()
