-- Unimplemented streams exercises

-- streams are never-empty lists

type Stream a = [a]

-- utils
(><) :: (a -> b) -> (c -> d) -> (a, c) -> (b, d)
(><) f g (a,c) = (f a, g c)

swap :: (a, b) -> (b, a)
swap (a,b) = (b,a)

--------------------------------------------------------------------------------
univ :: (a -> b) -> (a -> a) -> a -> Stream b
univ obs nxt seed = []

nats :: Stream Int
nats = []

evens :: Stream a -> Stream a
evens = const []

odds :: Stream a -> Stream a
odds = const []

repeat' :: a -> Stream a
repeat' = const []

map' :: (a -> b) -> Stream a -> Stream b
map' f = const []

interleave :: Stream a -> Stream a -> Stream a
interleave = const (const [])

zip' :: Stream a -> Stream b -> Stream (a, b)
zip' = const (const [])

suffixes :: Stream a -> Stream (Stream a)
suffixes = const []

prod :: Stream a -> Stream b -> Stream (Stream (a, b))
prod = const (const [])

diag :: Stream (Stream a) -> Stream a
diag = const []

fib :: Stream Int
fib = []

look_and_say :: Int -> Stream Int
look_and_say = const []


--------------------------------------------------------------------------------
main :: IO ()
main = do
  print $ take 5 nats
  print $ take 5 $ evens nats
  print $ take 5 $ odds  nats
  print $ take 5 $ repeat' "zzz"
  print $ take 5 $ map' ((+)10) nats
  print $ take 5 $ map' (take 5) $ suffixes nats
  print $ take 5 $ interleave (evens nats) (odds nats)
  print $ take 5 $ diag $ prod nats nats
  print $ take 5 $ fib
  print $ take 5 $ look_and_say 1
