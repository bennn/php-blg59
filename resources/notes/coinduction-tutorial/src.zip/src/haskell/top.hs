-- streams are never-empty lists
type Stream a = [a]

-- utils
(><) :: (a -> b) -> (c -> d) -> (a, c) -> (b, d)
(><) f g (a,c) = (f a, g c)

swap :: (a, b) -> (b, a)
swap (a,b) = (b,a)

--------------------------------------------------------------------------------
univ :: (a -> b) -> (a -> a) -> a -> Stream b
univ obs nxt seed = (obs seed) : univ obs nxt (nxt seed)

nats :: Stream Int
nats = univ id ((+) 1) 0

evens :: Stream a -> Stream a
evens = univ head (tail . tail)

odds :: Stream a -> Stream a
odds = evens . tail

repeat' :: a -> Stream a
repeat' = univ id id

map' :: (a -> b) -> Stream a -> Stream b
map' f = univ (f . head) tail

interleave :: Stream a -> Stream a -> Stream a
interleave = curry $ univ (head . fst) (swap . (tail >< id))

zip' :: Stream a -> Stream b -> Stream (a, b)
zip' = curry $ univ (head >< head) (tail >< tail)

suffixes :: Stream a -> Stream (Stream a)
suffixes = univ id tail

prod :: Stream a -> Stream b -> Stream (Stream (a, b))
prod = curry $ univ ((uncurry zip') . ((repeat' . head) >< id)) (tail >< id)

diag :: Stream (Stream a) -> Stream a
diag = univ (head . head) (tail . (map' tail))

fib :: Stream Int
fib = univ snd (\(a,b) -> (b, a + b)) (0, 1)

look_and_say :: Int -> Stream Int
look_and_say = univ id nxt
  where nxt = read . reverse . (uncurry (++)) . (say >< id)
              . foldl look ("","") . show
        look (prev, acc) n
           | (p:ps) <- prev, p == n = (n:prev, acc)
        look (prev, acc) n = ([n], say prev ++ acc)
        say [] = []
        say (x:xs) = x : show (length (x:xs))
                

--------------------------------------------------------------------------------
main :: IO ()
main = do
  print $ take 5 nats
  print $ take 5 $ evens nats
  print $ take 5 $ odds  nats
  print $ take 5 $ repeat' "zzz"
  print $ take 5 $ map' ((+)10) nats
  print $ take 5 $ map' (take 5) $ suffixes nats
  print $ take 5 $ interleave (odds nats) (evens nats)
  print $ take 5 $ diag $ prod nats nats
  print $ take 5 $ fib
  print $ take 5 $ look_and_say 1
